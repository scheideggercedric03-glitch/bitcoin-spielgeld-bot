# Bitcoin-Daytrading-Bot – Version 0.1 (nur Spielgeld)

Dieser Python-Bot ruft öffentliche **BTC/CHF**-5-Minuten-Kerzen von Kraken ab. Es gibt **keine Handelsberechtigung, keine echten Orders, keinen API-Schlüssel**. Kontostand, Positionen und die Handelsliste werden lokal gespeichert.

## Start

Python 3.10+ installieren. Im Terminal im entpackten Ordner:

```bash
python bot.py
```

Mit `Ctrl+C` beenden. Für einen 24/7-Betrieb muss das Programm auf einem eigenen laufenden Computer oder Server laufen. Der Bot läuft **nicht automatisch auf ChatGPT**.

## Strategie – erster Prototyp

- 100 CHF virtuelles Startkapital, 5-Minuten-Kerzen.
- SMA(5) kreuzt über SMA(20): Kauf von 25 % des freien virtuellen CHF-Guthabens.
- SMA(5) kreuzt unter SMA(20), -1 % Stop-Loss oder +2 % Gewinnschwelle: Verkauf.
- Tagesverlust-Schwelle 2 CHF, danach keine neuen Käufe bis zum nächsten UTC-Tag.
- Am Tageswechsel wird eine bestehende Position beim nächsten verarbeiteten Kurs geschlossen.
- Simulierte Gebühren 0,4 % je Seite plus 0,1 % hypothetischer Gesamtspread.
- Simulierte Ausführungen zum letzten Schlusskurs plus/minus Spread. Realität kann wegen Slippage, Gebühren, Ordergrössen und Ausführungszeit abweichen.

## Dateien

- `bot.py`: Quellcode
- `state.json`: automatisch angelegter virtueller Kontostand und letzter verarbeiteter Zeitstempel
- `trades.csv`: automatisch angelegte Handelsliste

Zum kompletten Reset das Programm stoppen und `state.json` und `trades.csv` löschen.

## Grenzen

**Dies ist kein trainiertes KI-Modell**, sondern zunächst eine vollständig regelbasierte, testbare Strategie. Ein echter ML-Ansatz braucht historische Trainingsdaten, eine separate zeitlich nachgelagerte Prüfung und längeres Paper-Trading. Kraken liefert über OHLC nur eine begrenzte Menge aktueller Kerzen. Der Bot verwendet nur abgeschlossene Kerzen und kann bei Verbindungsproblemen Trades verpassen. Ohne Laufzeitüberwachung, Intrabar-Stop-Aufträge und echte Orderausführung sind Verlustgrenzen nicht garantiert. Das System hat keine Echtgeldfunktion. Keine Gewinnprognose.

## Sicherheit

Keine API-Keys einfügen. Keine Kontoverknüpfung notwendig. Vor jeglichem Echtgeldbetrieb müssten technische und finanzielle Risiken erneut geprüft werden.
