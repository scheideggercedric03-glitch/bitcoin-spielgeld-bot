#!/usr/bin/env python3
"""BTC/CHF paper-only trading bot. No private keys, no real trading API."""
import csv
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode

BASE = 'https://api.kraken.com/0/public/'
HOME = Path(__file__).resolve().parent
STATE_FILE = HOME / 'state.json'
TRADES_FILE = HOME / 'trades.csv'
INITIAL_CHF = 100.0
FEE_RATE = 0.004  # hypothetical per side; verify actual trading fees
SPREAD_RATE = 0.001  # hypothetical full bid/ask spread
ALLOCATION = 0.25
STOP_LOSS = 0.01
TAKE_PROFIT = 0.02
MAX_DAILY_LOSS = 2.0
INTERVAL = 5
CHECK_SECONDS = 60


def api(endpoint, **params):
    url = BASE + endpoint + ('?' + urlencode(params) if params else '')
    req = Request(url, headers={'User-Agent': 'BTC-CHF-Paper-Bot/1.0'})
    with urlopen(req, timeout=20) as response:
        payload = json.load(response)
    if payload.get('error'):
        raise RuntimeError('Kraken API: ' + repr(payload['error']))
    return payload['result']


def find_pair():
    pairs = api('AssetPairs')
    for pair_id, info in pairs.items():
        alt = info.get('altname', '').upper()
        ws = info.get('wsname', '').upper()
        if (alt in ('XBTCHF', 'BTCCHF') or ws in ('XBT/CHF', 'BTC/CHF')) and info.get('status', 'online') == 'online':
            return pair_id
    raise RuntimeError('Kein aktives BTC/CHF-Handelspaar auf Kraken gefunden. Keine simulierten Trades ausgeführt.')


def candles(pair):
    result = api('OHLC', pair=pair, interval=INTERVAL)
    values = next(v for k, v in result.items() if k != 'last')
    # Kraken includes one currently forming candle; exclude it
    return [(int(r[0]), float(r[4])) for r in values[:-1]]


def initial_state():
    return {'cash_chf': INITIAL_CHF, 'btc': 0.0, 'entry_price': None,
            'last_candle': 0, 'day': '', 'day_start_equity': INITIAL_CHF,
            'paused_today': False, 'total_trades': 0}


def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text(encoding='utf8'))
    return initial_state()


def save_state(s):
    tmp = STATE_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps(s, indent=2), encoding='utf8')
    os.replace(tmp, STATE_FILE)


def log_trade(candle_time, side, price, qty, fee, reason, equity):
    new = not TRADES_FILE.exists()
    with TRADES_FILE.open('a', newline='', encoding='utf8') as f:
        w = csv.writer(f)
        if new:
            w.writerow(['utc_time', 'side', 'fill_price_chf', 'btc_qty', 'fee_chf', 'reason', 'equity_chf'])
        w.writerow([datetime.fromtimestamp(candle_time, timezone.utc).isoformat(), side,
                    f'{price:.2f}', f'{qty:.9f}', f'{fee:.4f}', reason, f'{equity:.2f}'])


def value(s, mid):
    return s['cash_chf'] + s['btc'] * mid


def buy(s, when, mid):
    amount = s['cash_chf'] * ALLOCATION
    if amount < 10:
        return
    fill = mid * (1 + SPREAD_RATE / 2)
    fee = amount * FEE_RATE
    qty = (amount - fee) / fill
    s['cash_chf'] -= amount
    s['btc'] += qty
    s['entry_price'] = fill
    s['total_trades'] += 1
    log_trade(when, 'BUY', fill, qty, fee, 'SMA crossover', value(s, mid))
    logging.info('SIM BUY %.8f BTC @ %.2f CHF; Gebuehr %.2f CHF', qty, fill, fee)


def sell(s, when, mid, reason):
    if s['btc'] <= 0:
        return
    fill = mid * (1 - SPREAD_RATE / 2)
    qty = s['btc']
    proceeds = qty * fill
    fee = proceeds * FEE_RATE
    s['cash_chf'] += proceeds - fee
    s['btc'] = 0.0
    s['entry_price'] = None
    s['total_trades'] += 1
    log_trade(when, 'SELL', fill, qty, fee, reason, value(s, mid))
    logging.info('SIM SELL %.8f BTC @ %.2f CHF; Grund %s', qty, fill, reason)


def process(s, history):
    if len(history) < 22:
        return
    when, mid = history[-1]
    if when <= s['last_candle']:
        return
    day = datetime.fromtimestamp(when, timezone.utc).date().isoformat()
    if s['day'] != day:
        # Close positions on the next observed bar after UTC midnight
        if s['btc']:
            sell(s, when, mid, 'UTC day boundary')
        s['day'] = day
        s['day_start_equity'] = value(s, mid)
        s['paused_today'] = False
    equity = value(s, mid)
    if equity <= s['day_start_equity'] - MAX_DAILY_LOSS:
        if s['btc']:
            sell(s, when, mid, 'Daily loss limit')
        s['paused_today'] = True
    p = [x[1] for x in history]
    fast_prev = sum(p[-6:-1]) / 5
    slow_prev = sum(p[-21:-1]) / 20
    fast_now = sum(p[-5:]) / 5
    slow_now = sum(p[-20:]) / 20
    if s['btc']:
        entry = s['entry_price']
        if mid <= entry * (1 - STOP_LOSS):
            sell(s, when, mid, 'Stop loss')
        elif mid >= entry * (1 + TAKE_PROFIT):
            sell(s, when, mid, 'Take profit')
        elif fast_prev >= slow_prev and fast_now < slow_now:
            sell(s, when, mid, 'SMA exit')
    elif not s['paused_today'] and fast_prev <= slow_prev and fast_now > slow_now:
        buy(s, when, mid)
    s['last_candle'] = when
    logging.info('Candle %s | BTC %.2f CHF | Konto %.2f CHF | Cash %.2f | BTC %.8f | Pause %s',
                 datetime.fromtimestamp(when, timezone.utc).isoformat(), mid, value(s, mid),
                 s['cash_chf'], s['btc'], s['paused_today'])
    save_state(s)


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    logging.info('PAPER MODE ONLY: Keine Echtgeldauftraege moeglich.')
    pair = None
    s = load_state()
    while True:
        try:
            pair = pair or find_pair()
            process(s, candles(pair))
        except (Exception) as exc:
            logging.exception('Marktdaten-/Verarbeitungsfehler: %s', exc)
        time.sleep(CHECK_SECONDS)


if __name__ == '__main__':
    main()
